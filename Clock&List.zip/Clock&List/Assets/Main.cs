﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour {


    public GameObject LoadImage;
    float LoadImageTime;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (LoadImage.activeSelf)
        {
            LoadImageTime += Time.deltaTime;
            if (LoadImageTime >= 8)
            {
                LoadImageTime = 0;
                LoadImage.SetActive(false);
            }
        }
	}
    public void QuitGame()
    {
        Application.Quit();
    }
}
