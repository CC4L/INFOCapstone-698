﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Click : MonoBehaviour {

    public GameObject ShowButton;
    float ShowTime;
    
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (ShowButton.activeSelf)
        {
            ShowTime += Time.deltaTime;
            if (ShowTime >= 5)
            {
                ShowTime = 0;
                ShowButton.SetActive(false);
            }
        }
    }
    public void ClickThis()
    {
        if (ShowButton.activeSelf)
        {
            ShowButton.SetActive(false);
        }
        else
        {
            ShowButton.SetActive(true);
        }
    }
}
