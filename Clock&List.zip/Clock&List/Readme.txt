Open Method: Use Unity to open project

Home Page: Click on the corresponding button to replace the corresponding page

Search Page: Enter the time and click the button to start searching. Click the close button to return to the homepage

Add Page: Enter the time and content. Click the save button to save

View all the records by sliding. Click on the record, the delete button appears. You can click to delete the current record 